export interface ViewCell {
  value: string | number;
  rowData: any;
}
