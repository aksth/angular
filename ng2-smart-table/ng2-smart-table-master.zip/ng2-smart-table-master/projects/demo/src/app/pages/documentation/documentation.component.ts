import { Component } from '@angular/core';

@Component({
  selector: 'demo',
  styleUrls: ['./documentation.component.scss'],
  templateUrl: './documentation.component.html',
})
export class DocumentationComponent {

}
