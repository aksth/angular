import { Component } from '@angular/core';

@Component({
  selector: 'server-examples',
  templateUrl: './server-examples.component.html',
})
export class ServerExamplesComponent {

}
